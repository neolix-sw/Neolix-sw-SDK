Before you start to catch log and make sure your PDA is in developer mode.
Steps:

1. Click to enter Settings app and find "About phone" item
2. Click to enter the "Build number" item , click on the item continuously, and according to the prompt information, "No need, you are alrady developer".
3. Return to the previous interface and find the "Developer Options".
4, click to enter, open "USB debugging"

How to catch the log

The mobile phone links the PC it is windows platform, and open terminal program and executes the "run_logcat.bat" file in the compressed package, log information is output on the screen.
Reproduce the problem until the operation ends, "Ctrl + c" terminates the log. Then send the call_fail.log email to aojiazhi@neolix.cn and cc to liudi@neolix.cn.

thanks.